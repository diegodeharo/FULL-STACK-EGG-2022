/*
 
 */
package MetodoMain;

import Entidad.Tienda;

/**
 *
 * @author Pc
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
      Tienda t1 = new Tienda();
      t1.menu();
//      t1.almacenar();
//      t1.mostrarProductos();
//      t1.modificar();
//      t1.EliminarProducto();
    }
    
}
