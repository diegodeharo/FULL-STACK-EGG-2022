/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package numero;

/**
 *
 * @author EL_SEMENTAL
 */
public enum Numero {
    
    uno,dos,tres, cuatro, cinco, seis, siete, diez, once, doce;
    
}
