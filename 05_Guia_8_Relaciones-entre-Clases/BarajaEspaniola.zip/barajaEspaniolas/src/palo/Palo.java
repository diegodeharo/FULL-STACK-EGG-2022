
package palo;


public enum Palo {
    
     BASTO, ESPADA, ORO, COPA;

//    BASTO("Basto"), ESPADA("Espada"), ORO("Oro"), COPA("Copa");
//
//    private String nombre;
//
//    private Palo() {
//    }
//
//    private Palo(String nombre) {
//        this.nombre = nombre;
//    }
//
//    public String getNombre() {
//        return nombre;
//    }
//
//    public void setNombre(String nombre) {
//        this.nombre = nombre;
//    }
    
    

}
